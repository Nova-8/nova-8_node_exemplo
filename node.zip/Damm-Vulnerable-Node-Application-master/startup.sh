#! /bin/bash

npm install
nodemon